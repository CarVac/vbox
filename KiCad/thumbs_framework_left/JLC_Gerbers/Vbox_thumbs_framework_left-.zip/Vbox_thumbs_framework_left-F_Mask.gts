G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.3+dfsg-1*
G04 #@! TF.CreationDate,2026-03-15T12:12:55-04:00*
G04 #@! TF.ProjectId,Vbox_thumbs_framework_left,56626f78-5f74-4687-956d-62735f667261,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.3+dfsg-1) date 2026-03-15 12:12:55*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.250000X-1.500000X0.250000X-1.500000X-0.250000X1.500000X-0.250000X1.500000X0.250000X0*%
%ADD11RoundRect,0.250001X-1.449999X0.499999X-1.449999X-0.499999X1.449999X-0.499999X1.449999X0.499999X0*%
G04 APERTURE END LIST*
D10*
X87850000Y-104800000D03*
X87850000Y-106800000D03*
X87850000Y-108800000D03*
X87850000Y-110800000D03*
X87850000Y-112800000D03*
X87850000Y-114800000D03*
D11*
X82100000Y-102450000D03*
X82100000Y-117150000D03*
M02*
