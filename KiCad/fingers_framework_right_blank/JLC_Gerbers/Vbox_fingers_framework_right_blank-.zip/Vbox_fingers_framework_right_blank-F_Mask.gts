%TF.GenerationSoftware,KiCad,Pcbnew,9.0.3+dfsg-1*%
%TF.CreationDate,2026-03-15T12:12:38-04:00*%
%TF.ProjectId,Vbox_fingers_framework_right_blank,56626f78-5f66-4696-9e67-6572735f6672,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.3+dfsg-1) date 2026-03-15 12:12:38*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
