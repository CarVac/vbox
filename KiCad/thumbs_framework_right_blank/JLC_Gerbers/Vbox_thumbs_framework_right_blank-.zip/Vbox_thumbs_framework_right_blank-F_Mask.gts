G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.3+dfsg-1*
G04 #@! TF.CreationDate,2026-03-15T12:13:43-04:00*
G04 #@! TF.ProjectId,Vbox_thumbs_framework_right_blank,56626f78-5f74-4687-956d-62735f667261,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.3+dfsg-1) date 2026-03-15 12:13:43*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
