%TF.GenerationSoftware,KiCad,Pcbnew,9.0.3+dfsg-1*%
%TF.CreationDate,2026-03-15T12:10:56-04:00*%
%TF.ProjectId,Vbox_fingers_framework_left,56626f78-5f66-4696-9e67-6572735f6672,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.3+dfsg-1) date 2026-03-15 12:10:56*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.250000X-1.500000X0.250000X-1.500000X-0.250000X1.500000X-0.250000X1.500000X0.250000X0*%
%ADD11RoundRect,0.250001X-1.449999X0.499999X-1.449999X-0.499999X1.449999X-0.499999X1.449999X0.499999X0*%
G04 APERTURE END LIST*
D10*
%TO.C,J1*%
X84850000Y-99000000D03*
X84850000Y-101000000D03*
X84850000Y-103000000D03*
X84850000Y-105000000D03*
X84850000Y-107000000D03*
X84850000Y-109000000D03*
X84850000Y-111000000D03*
X84850000Y-113000000D03*
X84850000Y-115000000D03*
X84850000Y-117000000D03*
D11*
X79100000Y-96650000D03*
X79100000Y-119350000D03*
%TD*%
M02*
